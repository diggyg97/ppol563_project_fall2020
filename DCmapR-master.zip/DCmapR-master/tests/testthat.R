library(testthat)
library(DCmapR)

test_check("DCmapR")
